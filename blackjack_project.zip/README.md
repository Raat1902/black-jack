# 🃏 Blackjack Game (C++)

A simple text-based Blackjack game in C++ where you play against a dealer.

## Features
- Full 52-card deck
- Hit / Stand functionality
- Dealer logic (stands at 17+)
- Ace logic (11 or 1)
- Win / Loss / Tie detection

## How to Run
1. Compile:
```bash
g++ -o blackjack main.cpp
```
2. Run:
```bash
./blackjack
```

## Future Improvements
- Add betting system
- Track win/loss stats
- Add menu + replay
- Build GUI version (using SFML)

## Screenshots
*(You can add terminal screenshots here)*
